# Reign — Netlify + GitHub (temps réel gratuit)

Suivi de prix Amazon.fr avec **catalogue 245+ produits** + section live.

## Sources de prix

| Priorité | Source | Coût | Rôle |
|----------|--------|------|------|
| 1 | **OpenWeb Ninja** | **Gratuit** (100 req/mois, sans carte) | Prix **temps réel** Amazon.fr |
| 2 | Keepa | Payant | Historique long + fallback |

## Obtenir la clé gratuite (2 min)

1. Va sur **https://www.openwebninja.com**
2. Crée un compte (pas de carte bancaire)
3. Abonne-toi au plan **Free** de **Real-Time Amazon Data** (100 requêtes / mois)
4. Copie ta clé API

## Variables d’environnement Netlify

Dans **Site configuration → Environment variables** :

```
OPENWEBNINJA_API_KEY = ta_clé_gratuite
OPENWEBNINJA_COUNTRY = FR
```

Optionnel (historique) :

```
KEEPA_API_KEY = ...
KEEPA_DOMAIN = 4
```

## Déploiement GitHub → Netlify

1. Pousse ce dossier à la racine de ton dépôt GitHub.
2. Netlify → Import existing project → sélectionne le repo.
3. Build command : `npm install` · Publish directory : `.`
4. Ajoute les variables d’environnement ci-dessus.
5. Deploy. Vérifie `/api/status` → `configured: true` et source OpenWeb Ninja.

## Temps réel

- Cron Netlify : **toutes les heures**
- Batch : 12 produits / exécution (rotation)
- UI : rafraîchissement auto **toutes les 90 s**
- Bouton « Relevé manuel » pour forcer un cycle

## Limites du free tier

- 100 requêtes OpenWeb Ninja / mois ≈ ~3 produits vérifiés chaque jour, ou ~100 ajouts uniques.
- Pour plus de volume : plan payant OpenWeb Ninja, ou ajoute Keepa, ou FlyByAPIs (aussi 100 free).

## Structure

```
index.html / reign.html
netlify.toml
package.json
netlify/functions/
  _store.mjs          ← OpenWeb Ninja + Keepa
  products.mjs
  poll.mjs
  scheduled-poll.mjs
  status.mjs
```
