import { getStore } from "@netlify/blobs";

const store = () => getStore("reign-price-tracker", { consistency: "strong" });
const empty = { products: {}, history: [] };

export async function readState() {
  const s = store();
  return (await s.get("state", { type: "json" })) || structuredClone(empty);
}

export async function writeState(state) {
  await store().setJSON("state", state);
}

export function parseAsin(value) {
  const s = String(value || "").trim();
  const m = s.match(/(?:\/dp\/|\/gp\/product\/|\/product\/)([A-Z0-9]{10})/i);
  const asin = (m ? m[1] : s).toUpperCase();
  if (!/^[A-Z0-9]{10}$/.test(asin)) throw new Error("Entre un ASIN de 10 caractères ou un lien produit Amazon.fr.");
  return asin;
}

export function errorResponse(message, status = 400) {
  return new Response(JSON.stringify({ message }), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

export function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

/** Parse Keepa csv series → price points */
export function parseKeepa(product) {
  const series = product?.csv?.[1] || [];
  const points = [];
  for (let i = 0; i + 1 < series.length; i += 2) {
    const t = series[i],
      raw = series[i + 1];
    if (typeof raw === "number" && raw > 0) {
      points.push({ price: raw / 100, date: new Date((t + 21564000) * 60000).toISOString() });
    }
  }
  const current = points.length ? points[points.length - 1].price : null;
  const lowestPoint = points.length ? points.reduce((a, b) => (b.price < a.price ? b : a)) : null;
  return { current, lowest: lowestPoint?.price ?? null, lowestDate: lowestPoint?.date ?? null, points };
}

/** Keepa (historique long) — optionnel */
export async function fetchKeepa(asin) {
  const key = process.env.KEEPA_API_KEY;
  if (!key) throw new Error("KEEPA_API_KEY manquante");
  const url = new URL("https://api.keepa.com/product");
  url.searchParams.set("key", key);
  url.searchParams.set("domain", process.env.KEEPA_DOMAIN || "4");
  url.searchParams.set("asin", asin);
  url.searchParams.set("history", "1");
  url.searchParams.set("stats", "365");
  const res = await fetch(url, { signal: AbortSignal.timeout(20000) });
  if (res.status === 429) throw new Error("Limite API Keepa atteinte.");
  if (!res.ok) throw new Error(`Keepa HTTP ${res.status}`);
  const data = await res.json();
  if (!data.products?.length) throw new Error("Produit introuvable Keepa Amazon France.");
  return data.products[0];
}

/**
 * OpenWeb Ninja — source temps réel GRATUITE (100 req/mois, sans carte)
 * https://www.openwebninja.com/api/real-time-amazon-data
 * Variable Netlify : OPENWEBNINJA_API_KEY
 */
export async function fetchOpenWebNinja(asin) {
  const key = process.env.OPENWEBNINJA_API_KEY;
  if (!key) throw new Error("OPENWEBNINJA_API_KEY manquante");
  const url = new URL("https://api.openwebninja.com/realtime-amazon-data/product-details");
  url.searchParams.set("asin", asin);
  url.searchParams.set("country", process.env.OPENWEBNINJA_COUNTRY || "FR");
  const res = await fetch(url, {
    headers: { "x-api-key": key },
    signal: AbortSignal.timeout(20000),
  });
  if (res.status === 429) throw new Error("Quota gratuit OpenWeb Ninja atteint (100 req/mois).");
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`OpenWeb Ninja HTTP ${res.status}${body ? " — " + body.slice(0, 120) : ""}`);
  }
  const data = await res.json();
  const p = data?.data || data;
  if (!p || (!p.product_title && !p.title && !p.asin)) {
    throw new Error("Réponse OpenWeb Ninja invalide ou produit introuvable.");
  }
  return p;
}

function parsePriceString(val) {
  if (val == null) return null;
  if (typeof val === "number" && Number.isFinite(val)) return val;
  const s = String(val).replace(/[^\d,.\-]/g, "").replace(",", ".");
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : null;
}

function normalizeOpenWebNinja(p, asin) {
  const title = p.product_title || p.title || asin;
  const price =
    parsePriceString(p.product_price_value) ??
    parsePriceString(p.product_price) ??
    parsePriceString(p.price) ??
    null;
  const image =
    p.product_photo ||
    (Array.isArray(p.product_photos) ? p.product_photos[0] : null) ||
    p.image ||
    null;
  return {
    title,
    current: price,
    image,
    source: "OpenWeb Ninja (live / gratuit)",
  };
}

/**
 * Mise à jour d’un produit :
 * 1. Priorité OpenWeb Ninja (temps réel gratuit)
 * 2. Fallback Keepa si clé présente (historique)
 */
export async function updateProduct(state, asin) {
  const previous = state.products[asin] || {};
  const now = new Date().toISOString();
  let title = previous.title || asin;
  let image = previous.image || null;
  let current = null;
  let lowest = previous.lowest_price ?? null;
  let lowestDate = previous.lowest_date ?? null;
  let source = "unknown";
  let pointsImported = 0;
  let usedLive = false;

  if (process.env.OPENWEBNINJA_API_KEY) {
    try {
      const raw = await fetchOpenWebNinja(asin);
      const n = normalizeOpenWebNinja(raw, asin);
      title = n.title || title;
      image = n.image || image;
      current = n.current;
      source = n.source;
      usedLive = true;
      if (current != null) {
        if (lowest == null || current < lowest) {
          lowest = current;
          lowestDate = now;
        }
      }
    } catch (e) {
      if (!process.env.KEEPA_API_KEY) throw e;
    }
  }

  if (process.env.KEEPA_API_KEY) {
    try {
      const p = await fetchKeepa(asin);
      const parsed = parseKeepa(p);
      title = p.title || title;
      if (p.imagesCSV) {
        image = `https://images-na.ssl-images-amazon.com/images/I/${p.imagesCSV.split(",")[0]}`;
      }
      pointsImported = parsed.points.length;
      if (!usedLive || current == null) {
        current = parsed.current;
        source = "Keepa / Amazon.fr";
      }
      if (parsed.lowest != null) {
        if (lowest == null || parsed.lowest < lowest) {
          lowest = parsed.lowest;
          lowestDate = parsed.lowestDate || lowestDate;
        }
      }
    } catch (e) {
      if (!usedLive) throw e;
    }
  }

  if (!process.env.OPENWEBNINJA_API_KEY && !process.env.KEEPA_API_KEY) {
    throw new Error(
      "Aucune clé API configurée. Ajoute OPENWEBNINJA_API_KEY (gratuit, 100 req/mois) ou KEEPA_API_KEY dans Netlify."
    );
  }

  const item = {
    asin,
    title,
    image,
    url: `https://www.amazon.fr/dp/${asin}`,
    current_price: current,
    lowest_price: lowest,
    lowest_date: lowestDate,
    last_checked: now,
    currency: "EUR",
    status: current == null ? "no_price" : "ok",
    samples: (previous.samples || 0) + (current == null ? 0 : 1),
    source,
  };
  state.products[asin] = item;
  if (current != null) {
    state.history.push({ asin, price: current, checked_at: now, source });
  }
  if (state.history.length > 20000) state.history = state.history.slice(-20000);
  return { ...item, points_imported: pointsImported };
}

export function getProviderInfo() {
  const hasOwn = Boolean(process.env.OPENWEBNINJA_API_KEY);
  const hasKeepa = Boolean(process.env.KEEPA_API_KEY);
  return {
    openwebninja: hasOwn,
    keepa: hasKeepa,
    configured: hasOwn || hasKeepa,
    primary: hasOwn ? "OpenWeb Ninja (gratuit / live)" : hasKeepa ? "Keepa" : null,
  };
}
