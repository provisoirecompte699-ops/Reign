import { json, getProviderInfo } from "./_store.mjs";

export default async () => {
  const info = getProviderInfo();
  return json({
    configured: info.configured,
    provider: info.primary || "Aucune clé configurée",
    sources: {
      openwebninja: info.openwebninja
        ? "Actif — temps réel gratuit (100 req/mois)"
        : "Non configuré (OPENWEBNINJA_API_KEY)",
      keepa: info.keepa ? "Actif — historique Amazon.fr" : "Non configuré (KEEPA_API_KEY)",
    },
    poll_hours: 1,
    storage: "Netlify Blobs",
    realtime: true,
    free_tier_note:
      "OpenWeb Ninja : 100 requêtes gratuites / mois, sans carte bancaire. Idéal pour tester le suivi live.",
    message: info.configured
      ? `Suivi actif via ${info.primary}. Relevé planifié chaque heure + rafraîchissement UI 90 s.`
      : "Ajoute OPENWEBNINJA_API_KEY (gratuit) ou KEEPA_API_KEY dans les variables d’environnement Netlify.",
  });
};
