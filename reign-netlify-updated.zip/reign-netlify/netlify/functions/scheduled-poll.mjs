import { readState, writeState, updateProduct } from "./_store.mjs";

export default async () => {
  if (!process.env.OPENWEBNINJA_API_KEY && !process.env.KEEPA_API_KEY) {
    console.error("Aucune clé API (OPENWEBNINJA ou KEEPA) : relevé ignoré.");
    return new Response("No API key configured", { status: 200 });
  }
  const state = await readState();
  const asins = Object.keys(state.products);
  // Scheduled Functions have a 30-second limit: rotate through products in bounded batches.
  const batchSize = 12;
  const start = asins.length ? ((state.pollCursor || 0) % asins.length) : 0;
  const batch = asins.length ? Array.from({ length: Math.min(batchSize, asins.length) }, (_, i) => asins[(start + i) % asins.length]) : [];
  for (const asin of batch) {
    try { await updateProduct(state, asin); }
    catch (e) { state.products[asin].status = "error: " + String(e.message).slice(0, 160); console.error("Price check failed", asin, e.message); }
  }
  state.pollCursor = asins.length ? (start + batch.length) % asins.length : 0;
  await writeState(state);
  return new Response(`Reign scheduled check: processed ${batch.length} of ${asins.length} products`, { status: 200 });
};
export const config = { schedule: "0 * * * *" };
